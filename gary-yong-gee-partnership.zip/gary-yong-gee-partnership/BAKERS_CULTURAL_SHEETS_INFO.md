# Baker's Cultural Sheets Integration

## What Are Baker's Cultural Sheets?

Baker's Cultural Sheets are comprehensive orchid care guides developed by Charles and Margaret Baker. These detailed cultural information sheets provide specific growing requirements for thousands of orchid species, including:

- **Temperature requirements** (day/night, seasonal variations)
- **Humidity preferences** (optimal ranges and seasonal changes)
- **Light requirements** (intensity and duration)
- **Water and fertilizer schedules**
- **Growing media recommendations**
- **Rest period requirements**
- **Repotting guidelines**
- **Common problems and solutions**

## Integration with Your Partnership

### Available Through API

Your partnership includes access to Baker's cultural data for species in your collection:

```html
<!-- Cultural care widget -->
<ocw-cultural-care data-taxon="Cattleya labiata"></ocw-cultural-care>
```

### API Endpoint

```bash
curl -H "Authorization: Bearer GYG_ck2z8F7vN9mH3xB5qL4wE1rT6pU9sA8dG0jV7yI2" \
  "https://api.orchidcontinuum.org/partner/cultural-sheets/Cattleya%20labiata"
```

**Response includes:**
- Temperature ranges (cool, intermediate, warm)
- Humidity requirements by season
- Light intensity recommendations
- Watering frequency guidelines
- Fertilizer programs
- Rest period information
- Media and mounting preferences

### Data Upload Enhancement

When uploading your orchid data, you can now include cultural observations:

```csv
source_id,scientific_name,image_url,cultural_notes,temperature_observed,humidity_observed,light_conditions,growing_medium
gyg-001,Cattleya labiata,https://orchids.yonggee.name/images/cat1.jpg,"Blooms best with cool nights",18-28C,70-80%,bright indirect,bark mix
```

### Widget Integration

The cultural sheets integrate seamlessly with your existing widgets:

```html
<!-- Enhanced search with cultural data -->
<ocw-search data-include-cultural="true" 
            data-placeholder="Search orchids with care info..."></ocw-search>

<!-- Cultural care panel -->
<ocw-cultural-care data-taxon="Dendrobium" 
                   data-show-seasonal="true"
                   data-include-images="true"></ocw-cultural-care>
```

### Benefits for Your Visitors

1. **Species-specific care guides** matched to your collection
2. **Seasonal care calendars** for optimal growing
3. **Problem diagnosis tools** with Baker's expertise
4. **Growing environment comparisons** with natural habitats
5. **Success tracking** for different cultural approaches

### Implementation Steps

1. **Request cultural data access** - Email partners@orchidcontinuum.org
2. **Update your orchid records** with cultural observations
3. **Add cultural care widgets** to species pages
4. **Enable care notifications** for seasonal changes
5. **Track growing success** with Baker's recommendations

### Example Integration

```html
<!-- On your species pages -->
<div class="orchid-care-section">
    <h3>Care Requirements - Baker's Cultural Sheets</h3>
    <ocw-cultural-care data-taxon="Cattleya labiata" 
                       data-theme="light"
                       data-show-seasonal="true"
                       data-include-troubleshooting="true"></ocw-cultural-care>
</div>
```

### Cultural Data Fields Available

- **Temperature**: Min/max day and night temperatures by season
- **Humidity**: Optimal ranges and seasonal adjustments
- **Light**: Footcandle requirements and photoperiod
- **Water**: Frequency, quality, and seasonal changes
- **Air Movement**: Ventilation requirements
- **Fertilizer**: NPK ratios and feeding schedules
- **Media**: Substrate preferences and drainage needs
- **Rest Periods**: Duration and environmental changes needed

This integration transforms your website into a comprehensive orchid care resource, combining your collection expertise with Baker's decades of cultural research.

**Next Steps:** Contact partners@orchidcontinuum.org to activate Baker's cultural sheets for your API key.
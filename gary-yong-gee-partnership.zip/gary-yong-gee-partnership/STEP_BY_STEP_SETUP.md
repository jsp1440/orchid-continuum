# Gary Yong Gee - Complete Setup Guide

## 🚀 **Step 1: Test the Demo (5 minutes)**

1. **Download this entire folder** to your computer
2. **Open `demo.html`** in any web browser
3. **See the widgets working** - this shows you exactly what visitors will see on your website
4. **Your API Key** is already configured in the demo

---

## 🔧 **Step 2: Add to Your Website (10 minutes)**

### **Method A: Simple Copy-Paste**
1. **Upload `ocw-widgets.umd.js`** to your website's files
2. **Add this ONE line** to your website's `<head>` section:

```html
<script src="ocw-widgets.umd.js"
        data-api-base="https://api.orchidcontinuum.org"
        data-api-key="GYG_ck2z8F7vN9mH3xB5qL4wE1rT6pU9sA8dG0jV7yI2"
        data-partner="gary-yong-gee"></script>
```

3. **Add widgets anywhere** you want them to appear:

```html
<!-- Search box for your orchids -->
<ocw-search data-placeholder="Search Gary's orchid collection..."></ocw-search>

<!-- Interactive map -->
<ocw-map></ocw-map>

<!-- Flowering timeline charts -->
<ocw-phenology data-taxon="Dendrobium"></ocw-phenology>
```

### **Method B: Use CDN (Recommended)**
Just add this to your `<head>`:

```html
<script src="https://cdn.orchidcontinuum.org/widgets/ocw-widgets.umd.js"
        data-api-base="https://api.orchidcontinuum.org"
        data-api-key="GYG_ck2z8F7vN9mH3xB5qL4wE1rT6pU9sA8dG0jV7yI2"
        data-partner="gary-yong-gee"></script>
```

Then use the same widget tags above.

---

## 📊 **Step 3: Upload Your Orchid Data (15 minutes)**

### **Option 1: CSV Upload (Easiest)**

1. **Create a CSV file** with your orchid data:

```csv
source_id,scientific_name,image_url,credit,license,locality,event_date,lat,lng,geo_visibility
gyg-001,Cattleya labiata,https://orchids.yonggee.name/images/image1.jpg,Gary Yong Gee,CC-BY-NC,Brazil,2023-10-14,-23.5,-46.6,partner_private
gyg-002,Dendrobium nobile,https://orchids.yonggee.name/images/image2.jpg,Gary Yong Gee,CC-BY-NC,Thailand,2023-09-20,18.8,98.9,public
```

2. **Upload using this command** (or use Postman/Insomnia):

```bash
curl -X POST https://api.orchidcontinuum.org/partner/upload-csv \
  -H "Authorization: Bearer GYG_ck2z8F7vN9mH3xB5qL4wE1rT6pU9sA8dG0jV7yI2" \
  -F "file=@your_orchids.csv"
```

### **Option 2: Share an Export URL**
1. **Email us** your existing orchid database export URL
2. **We'll import automatically** and handle all the formatting
3. **Set up sync** so new orchids appear automatically

### **Option 3: Export from Your Current System**
1. **Export from your current database** to JSON/CSV
2. **Email the file** to partners@orchidcontinuum.org
3. **We'll handle the upload** and data formatting for you

---

## 🗺️ **Step 4: Configure Location Privacy (5 minutes)**

Choose privacy levels for your orchid locations:

- **`public`** = Exact coordinates shown to everyone
- **`partner_private`** = Exact coordinates only for partner API holders
- **`internal_private`** = Always shows generalized locations

**Recommendation:** Use `partner_private` for sensitive species, `public` for common ones.

---

## 🎨 **Step 5: Customize the Look (Optional)**

### **Change Widget Colors:**
```html
<ocw-search data-theme="dark"></ocw-search>
<ocw-map data-theme="light"></ocw-map>
```

### **Custom Placeholders:**
```html
<ocw-search data-placeholder="Find orchids in Gary's collection..."></ocw-search>
```

### **Specific Map Regions:**
```html
<ocw-map data-bounds="-25,-50,-20,-45"></ocw-map>
```

---

## 🧪 **Step 6: Test Everything (10 minutes)**

1. **Visit your website** with the widgets installed
2. **Try searching** for orchid names
3. **Check the map** shows your locations (with privacy respected)
4. **Test different devices** - mobile, tablet, desktop
5. **Verify images load** from your website URLs

---

## 🆘 **Need Help?**

### **Instant Support:**
- **Email:** partners@orchidcontinuum.org
- **Include:** Your API key, website URL, and specific issue
- **Response time:** Usually within 24 hours

### **Common Issues:**

**Widgets not showing?**
- Check browser console for JavaScript errors
- Verify your API key is correct
- Make sure `ocw-widgets.umd.js` file loaded

**Data not appearing?**
- Check you uploaded data successfully
- Verify image URLs are publicly accessible
- Confirm CSV format matches our template

**Images not loading?**
- Images must be publicly accessible URLs
- HTTPS preferred over HTTP
- Check file permissions on your server

---

## 📈 **Step 7: Go Live! (5 minutes)**

1. **Remove any test content** from your pages
2. **Add the widgets** to your main orchid pages
3. **Announce the integration** to your visitors
4. **Share your API key safely** (never in public code)

---

## 🎉 **You're Done!**

Your website now has:
- ✅ **Real-time orchid search** across your collection
- ✅ **Interactive maps** with geoprivacy protection  
- ✅ **Phenology charts** showing flowering patterns
- ✅ **Automatic updates** when you add new orchids
- ✅ **Professional integration** with the Orchid Continuum

**Total setup time:** About 45 minutes

**Your visitors get:** Advanced orchid search, discovery, and research tools powered by your expert collection.

---

**Questions?** Just email us - we're here to make this work perfectly for you!
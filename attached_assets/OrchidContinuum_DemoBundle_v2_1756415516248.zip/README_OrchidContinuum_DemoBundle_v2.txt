This is the Orchid Continuum Demo Bundle v2.
Drop into Replit HTML project.